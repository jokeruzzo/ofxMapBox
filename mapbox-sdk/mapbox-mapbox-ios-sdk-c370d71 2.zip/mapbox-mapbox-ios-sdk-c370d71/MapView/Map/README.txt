The Route-Me project is receiving frequent updates from its developer community. For 
this reason, you'll probably want to have your hands on the source of Route-Me while 
you're developing your own project. If you want to link the Route-Me .xcodeproj to your
own program, please follow the Embedding Guide, found at
http://github.com/Alpstein/route-me/wiki/Embedding-Guide
Use the "MapView" target.

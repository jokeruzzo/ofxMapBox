//
//  FlipsideView.h
//  MapTestbed : Diagnostic map
//

#import <UIKit/UIKit.h>

@interface FlipsideView : UIView
{
}

@end

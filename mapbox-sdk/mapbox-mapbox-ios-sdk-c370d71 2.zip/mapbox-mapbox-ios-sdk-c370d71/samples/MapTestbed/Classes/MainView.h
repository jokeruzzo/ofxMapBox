//
//  MainView.h
//  MapTestbed : Diagnostic map
//

#import <UIKit/UIKit.h>

@interface MainView : UIView
{
}

@end

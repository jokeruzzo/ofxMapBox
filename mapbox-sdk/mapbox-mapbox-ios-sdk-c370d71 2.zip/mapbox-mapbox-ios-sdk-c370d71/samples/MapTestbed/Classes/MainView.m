//
//  MainView.m
//  MapTestbed : Diagnostic map
//

#import "MainView.h"

@implementation MainView

- (id)initWithFrame:(CGRect)frame
{
    if (!(self = [super initWithFrame:frame]))
        return nil;

    return self;
}

- (void)drawRect:(CGRect)rect
{
    // Drawing code
}

- (void)dealloc
{
    [super dealloc];
}

@end

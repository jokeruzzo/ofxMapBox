//
//  FlipsideView.h
//  SampleMap : Diagnostic map
//

#import <UIKit/UIKit.h>

@interface FlipsideView : UIView

@end

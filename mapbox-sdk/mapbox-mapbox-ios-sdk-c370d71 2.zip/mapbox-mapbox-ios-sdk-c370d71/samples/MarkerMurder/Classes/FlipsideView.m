//
//  FlipsideView.m
//  SampleMap : Diagnostic map
//

#import "FlipsideView.h"

@implementation FlipsideView

- (id)initWithFrame:(CGRect)frame
{
    if (!(self = [super initWithFrame:frame]))
        return nil;

    return self;
}

@end

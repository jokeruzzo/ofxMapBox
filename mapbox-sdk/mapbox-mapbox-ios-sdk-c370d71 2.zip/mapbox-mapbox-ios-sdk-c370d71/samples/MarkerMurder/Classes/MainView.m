//
//  MainView.m
//  SampleMap : Diagnostic map
//

#import "MainView.h"

@implementation MainView

- (id)initWithFrame:(CGRect)frame
{
    if (!(self = [super initWithFrame:frame]))
        return self;

    return self;
}

@end

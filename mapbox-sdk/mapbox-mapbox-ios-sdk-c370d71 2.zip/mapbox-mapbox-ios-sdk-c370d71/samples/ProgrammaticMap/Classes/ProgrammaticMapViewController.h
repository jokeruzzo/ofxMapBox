//
//  ProgrammaticMapViewController.h
//  ProgrammaticMap
//
//  Created by Hal Mueller on 3/25/09.
//  Copyright Route-Me Contributors 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EagleScrollView.h"
#import "mapSubView.h"

@interface ProgrammaticMapViewController : UIViewController <RMMapViewDelegate>{
    
    CGPoint  startPoint;
}

@property (nonatomic, retain) mapSubView  *mapView;
@property (nonatomic, retain) EagleScrollView *eagleScrollView;


- (IBAction)doTheTest:(id)sender;
- (IBAction)takeSnapshot:(id)sender;

@end


//
//  ProgrammaticMapViewController.m
//  ProgrammaticMap
//
//  Created by Hal Mueller on 3/25/09.
//  Copyright Route-Me Contributors 2009. All rights reserved.
//

#import "ProgrammaticMapViewController.h"
#import "RMMapView.h"
#import "touchsendersubview.h"

#define POS2_LATITUDE		 52.370216 
#define POS2_LONGITUDE		 4.895168


@implementation ProgrammaticMapViewController

@synthesize mapView;
@synthesize eagleScrollView;


- (void)viewDidLoad
{
       eagleScrollView = nil;
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    
   

    
   
//    NSLog(@"viewDidLoad");
//    [super viewDidLoad];



    mapView = [[[mapSubView alloc] initWithFrame:CGRectMake(10, 20, 300, 340)] autorelease];
    mapView.adjustTilesForRetinaDisplay = NO;
    
    startPoint =  mapView._mapScrollView.contentOffset;
 
    
    CGRect viewFrame = CGRectMake(mapView._mapScrollView.contentOffset.x,
                                  mapView._mapScrollView.contentOffset.y,
                                 100,
                                   100);
    
    
    
    
    // touchsendersubview* containerView = [[touchsendersubview
    touchsendersubview* containerView = [[[touchsendersubview alloc] initWithFrame:viewFrame] autorelease];
   
    
    
    
   
   // [mapView._RMMapScrollView bringSubviewToFront:containerView];
    [[self view] addSubview:mapView];
    [[self view] sendSubviewToBack:mapView];
  //[self.view addSubview:containerView];
   
  //   [mapView._overlayView moveLayersBy:_accumulatedDelta];
    [self createEagleView];
//  [mapView._mapScrollView addSubview:containerView];
   //[mapView._mapScrollView bringSubviewToFront:containerView];
     //  containerView.mapView = mapView;
    
  }


- (void) createEagleView{
    
    
    CLLocationCoordinate2D secondLocation;
     secondLocation.latitude = POS2_LATITUDE;
    secondLocation.longitude = POS2_LONGITUDE;
    
    mapView.centerProjectedPoint.x;
    
    CLLocationCoordinate2D normLoc = [self.mapView   normalizeCoordinate:secondLocation];
    
   // [self.mapView setCenterCoordinate:secondLocation];
   
    CGPoint coordinPixel = [self.mapView coordinateToPixel:normLoc];
    RMProjectedPoint projPoint = [self.mapView coordinateToProjectedPoint:secondLocation];   
       CGPoint point =  [self.mapView projectedPointToPixel:projPoint];
   // CGPoint pixCoordinate = [mapView pixelToCoordinate: secondLocation];
    
    [self.mapView setCenterProjectedPoint:projPoint];

  //  RMProjectedPoint projOrgin = [mapView projectedOrigin:
    NSLog(@"POINT %@", NSStringFromCGPoint(point));
    NSLog(@"PIXEL %@", NSStringFromCGPoint(coordinPixel));
    NSLog(@"projectedPoint %e",projPoint.x);
    NSLog(@"projectedPoint %e",projPoint.y);
    NSLog(@"OFFSET %@", NSStringFromCGPoint(mapView._mapScrollView.contentOffset
                                            ));

//    
//    CGRect viewFrame = CGRectMake(mapView._mapScrollView.contentOffset.x,mapView._mapScrollView.contentOffset.y,
//                                  100, 100);
//   // eagleScrollView = [[EagleScrollView alloc] initWithFrame:[mapView._mapScrollView bounds]];
//    //[mapView._mapScrollView bounds]]
//    eagleScrollView = [[[EagleScrollView alloc] initWithFrame:viewFrame] autorelease];
//     CGRect bounds = CGRectMake(projPoint.x,projPoint.y, mapView._overlayView.frame.size.width/2, mapView._overlayView.frame.size.height/2);
//    [self.mapView._mapScrollView addSubview:eagleScrollView ];
//    
//    
//    [mapView._mapScrollView bringSubviewToFront:eagleScrollView];
  ///  eagleScrollView.frame = bounds;
    // eagleScrollView.userInteractionEnabled = NO;
    
    
    
}
- (CGSize)contentSize{
    
    return mapView._mapScrollView.contentSize;
    
}
- (CGPoint) ContentOffset{
    
    
    return mapView._mapScrollView.contentOffset;
    
}




- (void)dealloc
{
    [mapView removeFromSuperview];
    self.mapView = nil;
    [super dealloc];
}

- (IBAction)doTheTest:(id)sender
{
    CLLocationCoordinate2D secondLocation;
   // secondLocation.latitude = 0;
    //secondLocation.longitude = 0;
   // [self.mapView setCenterCoordinate:secondLocation];
    NSLog(@"------------------Content---------");
    mapView._mapScrollView.contentOffset = startPoint;
   //  NSLog(@"%e",mapView._mapScrollView.contentOffset.x);
   //  NSLog(@"%e",mapView._mapScrollView.contentOffset.y);
     NSLog(@"------------------Content---------");
}

- (IBAction)takeSnapshot:(id)sender
{
    UIImage *snapshot = [self.mapView takeSnapshot];
    [UIImagePNGRepresentation(snapshot) writeToFile:[[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:@"snap.png"] atomically:YES];
}

@end

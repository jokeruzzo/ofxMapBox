//
//  RMSUBMAPVIEW.h
//  ProgrammaticMap
//
//  Created by Martijn Mellema on 20-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RMMapView.h"

@interface RMSUBMAPVIEW : RMMapView

@end

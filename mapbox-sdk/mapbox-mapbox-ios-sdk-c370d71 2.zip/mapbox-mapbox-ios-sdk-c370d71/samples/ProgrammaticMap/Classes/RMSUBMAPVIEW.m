//
//  RMSUBMAPVIEW.m
//  ProgrammaticMap
//
//  Created by Martijn Mellema on 20-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RMSUBMAPVIEW.h"

@implementation RMSUBMAPVIEW

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end

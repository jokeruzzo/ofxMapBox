//
//  mapSubView.m
//  ProgrammaticMap
//
//  Created by Martijn Mellema on 20-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "mapSubView.h"



@implementation mapSubView

@synthesize eagleScrollView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //[self addGestureRecognizer:mapView._mapScrollView];
        
        CGRect viewFrame = CGRectMake(self._mapScrollView.contentOffset.x,self._mapScrollView.contentOffset.y,
                                      100, 100);
   
        eagleScrollView = [[[EagleScrollView alloc] initWithFrame:viewFrame] autorelease];
       
      [self._mapScrollView addSubview:eagleScrollView ];
        
        
        [self._mapScrollView bringSubviewToFront:eagleScrollView];

    }
    return self;
}



- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    
    eagleScrollView.center = CGPointMake(self._mapScrollView.contentOffset.x, self._mapScrollView.contentOffset.y);  
       
}
@end

//
//  touchSenderSubviews.h
//  AHNATIVE002
//
//  Created by Martijn Mellema on 18-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "RMMapView.h"


@interface touchSenderSubviews : UIView <UIScrollViewDelegate>



@property (nonatomic,retain) RMMapView *mapView;



@end

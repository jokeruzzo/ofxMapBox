//
//  touchSenderSubviews.m
//  AHNATIVE002
//
//  Created by Martijn Mellema on 18-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "touchSenderSubviews.h"







@implementation touchSenderSubviews


@synthesize mapView;





- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        

        
//    
//        UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc]
//                                                      initWithTarget:self 
//                                                      action:@selector(onPan:)];
//        [self addGestureRecognizer:panRecognizer];
//         [panRecognizer setCancelsTouchesInView:NO];
//        [panRecognizer release];
// [mapView addGestureRecognizer:panRecognizer];
       if ( self.mapView){
           
           
            
        }

    }
    return self;
}

- (void)requireGestureRecognizerToFail:(UIGestureRecognizer *)otherGestureRecognizer{
    

}
//
//- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
//    
//    return YES;
//}


- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    NSLog(@"gestureRecognizerShouldBegin");
    
  if(mapView)
    {
        
        return [mapView gestureRecognizerShouldBegin:gestureRecognizer];
    }
    
    

    
    return false;
}

- (void)onPan:(id)event
{
   
    NSLog(@"ONPAN EVENT %@",event);
    if(otherView)
    {
        //EagleView onEagleView zijn eigen pan functie implementatie
    }
    if(mapView)
    {
       
         NSLog(@"pan"); 
        
        [mapView handlePanGesture:event];
       // [mapView 
        //[mapView moveBy:CGSizeMake(10, 10)];
    }
    
    
    
}




@end

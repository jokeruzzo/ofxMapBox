//
//  touchsendersubview.h
//  ProgrammaticMap
//
//  Created by Martijn Mellema on 19-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMMapView.h"
#import <UIKit/UIGestureRecognizerSubclass.h>

@interface touchsendersubview : UIScrollView

@property (nonatomic,retain) RMMapView *mapView;

- (void) gestureRecognizer:(UIGestureRecognizer *)gr movedWithTouches:(NSSet*)touches andEvent:(UIEvent *)event;

@end

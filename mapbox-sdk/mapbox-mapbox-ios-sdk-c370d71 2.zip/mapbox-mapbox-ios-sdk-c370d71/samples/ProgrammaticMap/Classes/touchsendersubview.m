//
//  touchsendersubview.m
//  ProgrammaticMap
//
//  Created by Martijn Mellema on 19-07-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "touchsendersubview.h"

@implementation touchsendersubview

@synthesize mapView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        
        
        UIPanGestureRecognizer *panRecognizer = [[UIPanGestureRecognizer alloc]
                                                 initWithTarget:self 
                                                 action:@selector(onPan:)];
        [self addGestureRecognizer:panRecognizer];
        
        [panRecognizer setCancelsTouchesInView:NO];
        panRecognizer.minimumNumberOfTouches = 1;
        panRecognizer.maximumNumberOfTouches = 1;
        
        
        
        // the delegate is used to decide whether a pan should be handled by this
        // recognizer or by the pan gesture recognizer of the scrollview
        panRecognizer.delegate = self;
        
        self.pagingEnabled = YES;
        self.contentSize = CGSizeMake(1000, 1000);
       
        [panRecognizer release];
        self.backgroundColor = [UIColor redColor];
        
        
       // [mapView._RMMapScrollView :panRecognizer];
    }
    return self;
}



- (void)onPan:(id)event
{
    
  //  NSLog(@"ONPAN EVENT %@",event);
   
    if(mapView)
    {
       
        NSLog(@"pan"); 
        [mapView handlePanGesture:event];
            // [mapView 
        //[mapView moveBy:CGSizeMake(10, 10)];
    }
    
    
    
}


- (void)gestureRecognizer:(UIGestureRecognizer *)gr movedWithTouches:(NSSet *)touches andEvent:(UIEvent *)event{
    
     NSLog(@" Offset = %@ ",NSStringFromCGPoint(mapView._mapScrollView.contentOffset));
}


- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
  //  NSLog(@"touchesMoved");
       //  NSLog(@"%@", NSStringFromCGPoint(self.contentOffset));
    [super touchesMoved:touches withEvent:event];
    
   //   [(id)self.delegate gestureRecognizer:self movedWithTouches:touches andEvent:event];
//    
//    if ([self.delegate respondsToSelector:@selector(gestureRecognizer:movedWithTouches:andEvent:)]) {
////        [(id)self.delegate gestureRecognizer:self movedWithTouches:touches andEvent:event];
////    }
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@" Offset = %@ ",NSStringFromCGPoint(scrollView.contentOffset));
}
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    if(mapView)
    {
     //   [mapView._RMMapScrollView touchesBegan:touches withEvent:event];
    // 
    }
    [super touchesBegan:touches withEvent:event];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
